"""
    <network> : [<hiddenNeurons>][<outputNeurons>]
"""

